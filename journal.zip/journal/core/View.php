<?php 

class View
{
	//public $template_view; // здесь можно указать общий вид по умолчанию.//Метод получает указание на имя представления, а также на общий шаблон и опционально, если есть передает данные в представление. 
	
	function generate($content_view, $template_view, $data = null)
	{
		/*
		if(is_array($data)) {
			// преобразуем элементы массива в переменные
			extract($data);
		}
		*/
		
		include 'views/'.$template_view;
	}
}
//Метод generate включает в себя 3 входных параметра: имя общего шаблона представления - $template_view. Содержимое страницы – $content_view. Динамические данные полученные от модели $data. 

?>