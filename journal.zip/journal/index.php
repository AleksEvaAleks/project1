<?php 
	ini_set('error_reporting', E_ALL);
	ini_set('display_errors', 1);
	ini_set('display_startup_errors', 1);

	/*phpinfo();*/

/*$mysqli = mysqli_connect("127.0.0.1", "myuser", "mypassword", "POSTS");
if ($mysqli === false) {
 die("ERROR: Could not connect. " . mysqli_connect_error());
} else {
$res = $mysqli->query("SELECT * FROM last_news");
echo "<table>";
echo "<tr><th>ID</th><th>Title</th><th>Content</th><th>Postcard</th></tr>";
while ($row = $res->fetch_assoc()) {
 echo "<tr><td>".$row['id_news']."</td><td>".$row['title']."</td><td>".$row['content']."</td><td><img src='".$row['postcard']."' width='150'/></td></tr>";
}
echo "</table>";
mysqli_close($mysqli);
}*/


/*if (function_exists('mysqli_connect')) {
    echo "Расширение mysqli установлено и включено на сервере.";
} else {
    echo "Расширение mysqli не установлено или отключено на сервере.";
}*/


//Подключаем все наши общие классы: Модель, Контроллер и Представление 
require_once 'core/Model.php';
require_once 'core/View.php';
require_once 'core/Controller.php';
require_once 'core/Route.php';

Route::start(); // запускаем маршрутизатор*/

?>

