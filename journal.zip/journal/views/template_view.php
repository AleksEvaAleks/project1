<!DOCTYPE html>
<html lang="ru">
<head>
	<meta charset="utf-8">
	<link rel="stylesheet" href="style.css">
	<title>Главная</title>
</head>
<body>
	<?php include 'views/'.$content_view; ?>
</body>
</html>